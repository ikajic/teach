import check

###### Question 4
G1={1:[2,5], 2:[1,3], 3:[2], 4:[5], 5:[1,4]}
G2={1:[2,4], 2:[1,3,4,5], 3:[2,5], 4:[1,2], 5:[2,3], 6:[]}
G3={1:[2,3,4], 2:[1,3], 3:[1,2,5], 4:[1,5], 5:[3,4,6], 6:[5]}
G4={}


def edges_count(G):
    '''
    returns the number of edges in graph G
    
    count_vertices: (dictof Nat (listof Nat) -> Nat
    requires: Nat > 0
    
    Examples:
    count_edges(G1) => 5
    count_edges(G2) => 7
    '''
    ???
    

# Tests:
check.expect("T1", edges_count(G1), 4)
check.expect("T2", edges_count(G2), 6)
check.expect("T3", edges_count(G3), 7)
check.expect("T4", edges_count(G4), 0)   
