import check


####### Question 6a:

def list_dictionary(G):
    '''
    return the edge lists to represent G
    
    list_dictionary: (dictof Nat (listof Nat)) -> (listof (listof Nat))
    requires: Nat > 0
    
    Examples:
    list_dictionary({1:[2,5], 2:[1, 3, 5], 3:[2, 4], 4:[3, 5, 6], 5:[1, 2, 4], \
    6:[4]}) => [[1, 2], [1, 5], [2, 3], [2, 5], [3, 4], [4, 5], [4, 6]]
    list_dictionary({1:[2, 3], 2:[1], 3:[1]}) => [[1, 2], [1, 3]]
    
    '''
    ????
    
check.expect('t1', list_dictionary({1:[2,5], 2:[1, 3, 5], 3:[2, 4], \
                                    4:[3, 5, 6], 5:[1, 2, 4], 6:[4]}), \
            [[1, 2], [1, 5], [2, 3], [2, 5], [3, 4], [4, 5], [4, 6]])
check.expect('t2', list_dictionary({1:[2, 3], 2:[1], 3:[1]}), [[1, 2], [1, 3]])
