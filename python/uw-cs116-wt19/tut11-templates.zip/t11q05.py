import check


# Adjacency matrix representation - vertices 0,1,2,3,4,5 (slide 13)
g_adj_mat = [ [0,1,0,0,1,0], [1,0,1,0,1,0], [0,1,0,1,0,0],
              [0,0,1,0,1,1], [1,1,0,1,0,0], [0,0,0,1,0,0] ]


######## Question 5

def degree_adj_mat(G, v):
    ''' 
    returns the degree of vertex v in a graph G where G is an adjacency matrix 
    representation of a graph
      
    degree: (listof (listof Nat)) Nat -> Nat
    requires: 0 < len(G) == len(G[i]) for each i=0:len(G) 
              0 < v < len(G)
              
    Example: 
    degree_adj_mat([[0]], 0) => 0
    degree_adj_mat(g_adj_mat, 4) => 3 
    '''    
    ???
    
check.expect("degree - 1 vertex, deg 0", degree_adj_mat([[0]], 0), 0)
check.expect("degree - eg - v=0", degree_adj_mat(g_adj_mat, 0), 2)
check.expect("degree - eg - v=1", degree_adj_mat(g_adj_mat, 1), 3)
check.expect("degree - eg - v=2", degree_adj_mat(g_adj_mat, 2), 2)
check.expect("degree - eg - v=3", degree_adj_mat(g_adj_mat, 3), 3)
check.expect("degree - eg - v=4", degree_adj_mat(g_adj_mat, 4), 3)
check.expect("degree - eg - v=5", degree_adj_mat(g_adj_mat, 5), 1)
bigger_g = [ [0,1,0,0,1,0,0], [1,0,1,0,1,0,0], [0,1,0,1,0,0,0],
              [0,0,1,0,1,1,0], [1,1,0,1,0,0,0], [0,0,0,1,0,0,0],
              [0,0,0,0,0,0,0]]
check.expect("bigger graph, degree 0", degree_adj_mat(bigger_g, 6), 0)

