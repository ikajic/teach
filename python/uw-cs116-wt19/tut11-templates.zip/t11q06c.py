import check

######## Question 6c

def add_edge(G, a, b):
    '''
    mutated G by adding a new edge to it
    
    add_edge: (dictof Nat (listof Nat)) Nat Nat -> None
    requires: Nat > 0
    
    Examples:
    g1 = {1:[2,5], 2:[1, 3, 5], 3:[2, 4], 4:[3, 5, 6], 5:[1, 2, 4], \
    6:[4]}
    add_edge(g1,7,1) => None
    g1 = {1:[2,5,7], 2:[1, 3, 5], 3:[2, 4], 4:[3, 5, 6], 5:[1, 2, 4], \
    6:[4], 7:[1]}
    
    g2 = {1:[2, 3], 2:[1], 3:[1]}
    add_edge(g1,4,10) => None
    g2 = {1:[2, 3], 2:[1], 3:[1], 4:[10], 10:[4]}
    '''
    ???
        
g1 = {1:[2,5], 2:[1, 3, 5], 3:[2, 4], 4:[3, 5, 6], 5:[1, 2, 4], 6:[4]}
check.expect('t1', add_edge(g1,7,1), None)
check.expect('g1', g1, {1:[2,5,7], 2:[1, 3, 5], 3:[2, 4], 4:[3, 5, 6], \
                        5:[1, 2, 4], 6:[4], 7:[1]})

g2 = {1:[2, 3], 2:[1], 3:[1]}
check.expect('t2', add_edge(g2,4,5), None)
check.expect('g2', g2, {1:[2, 3], 2:[1], 3:[1], 4:[5], 5:[4]})
