## Tutorial 2

import check


## Question 3
## Fermat's Last Theorem states that given positive integers
## a, b, and n, there exists no integer c for which 
## a^n+b^n=c^n unless n=2. Although Fermat wrote the statement
## of this theorem in the margin of a book in 1637, it was not
## proven until 1995 (and not for lack of trying - thousands
## of incorrect proofs of the theorem were put forward before
## it was finally proven).
##
## Write a function fermat_check that consumes four positive
## integers, a, b, c, and n.
##   - If n = 2, and a^2+b^2=c^2, then your function should 
##     return "Pythagorean triple".
##   - If n = 2, and a^2+b^2 is not c^2, then your function
##     should return "Not a Pythagorean triple".
##   - If n > 2, and a^n+b^n=c^n, then your function should
##     return "Fermat was wrong!", as you have found a 
##     counterexample to Fermat's Last Theorem.
##   - Otherwise, your function should return
##     "Not a counterexample".

def fermat_check(a, b, c, n):
    '''
    checks if (a,b,c) form a Pythagorean triple, and returns a string 
      if n == 2. If n > 2, checks if a^n + b^n = c^n (which would be a 
      counterexample to Fermat's Last Theorem), and returns an appropriate 
      string
      
    fermat_check: ???
    requires: ???
    
    Examples:
    fermat_check(3, 4, 5, 2) => "Pythagorean triple"
    fermat_check(3, 4, 6, 2) => "Not a Pythagorean triple"
    fermat_check(3, 4, 5, 3) => "Not a counterexample"
    Since no know counterexample exists, we don't know anything
    that will yield "Fermat was wrong".
    '''
    
    ???

# Tests:
check.expect("FERMAT-1: n=2 PT", fermat_check(3, 4, 5, 2), "Pythagorean triple")
check.expect("FERMAT-2: n=2 NAPT", fermat_check(3, 4, 6, 2), "Not a Pythagorean triple")
check.expect("FERMAT-3: n>2 NAC", fermat_check(3, 4, 5, 3), "Not a counterexample")
