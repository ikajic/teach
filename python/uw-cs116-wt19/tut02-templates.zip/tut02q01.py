## Tutorial 2

import check

## Question 1
## Ensure you understand the results of calling
##   choices(8)
##   choices(10)
##   choices(100)
##   choices(111)
##   choices(250)
##   choices(360)

def choices(n):
    answer = 0
    if n % 2 == 0:
        answer = answer + 1
    if n % 3 == 0:
        answer = answer + 1
    elif n % 5 == 0:
        answer = answer + 1
    else:
        answer = 10 * answer
    if n % 10 == 0:
        answer = answer - 1
        if n % 4 == 0:
            answer = answer // 2
        else:
            answer = 2 * answer
    return answer
