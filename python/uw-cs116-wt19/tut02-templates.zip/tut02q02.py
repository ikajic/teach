## Tutorial 2

import check

## Question 2
## If you are given three sticks, you may or may not be able to
## arrange them in a triangle.
## If any of the three lengths is greater than the sum of the
## other two, then you cannot form a triangle. Otherwise, you
## can. If the sum of two lengths equals the third, they form
## what is called a "degenerate triangle".
## Write a function is_triangle that consumes three positive
## integers (s1,s2,and s3) representing the lengths of three
## sticks and produces one of the following:
##   - "No triangle exists" if no triangle can be built with 
##     the three sticks
##   - "Degenerate triangle exists" if only a degenerate triangle 
##     exists for sticks of these lengths
##   - "Triangle exists" if a triangle can be made from the sticks

def is_triangle(s1, s2, s3):
    '''
    returns "No triangle exists" if no non-degenerate triangle can be build 
      with sticks of these lengths; "Degenerate triangle exists" if only a 
      degenerate triangle exists for sticks of these lengths; "Triangle exists"
      if a triangle can be made from sticks of these lengths.
      
    is_triangle: ??? 
    requires: s1,s2,s3 > 0
    
    Examples:
    is_triangle(2,3,4) => "Triangle exists"
    is_triangle(2,3,5) => "Degenerate triangle exists"
    is_triangle(2,3,8) => "No triangle exists"
    '''

    ???
    
# Tests:
check.expect("tri-1: exists", is_triangle(2,3,4), "Triangle exists")
check.expect("tri-2: exists", is_triangle(4,3,2), "Triangle exists")
check.expect("tri-3: exists", is_triangle(3,4,2), "Triangle exists")
check.expect("tri-4: s1+s2==s3", is_triangle(2,3,5), "Degenerate triangle exists")
check.expect("tri-5: s1+s3==s2", is_triangle(3,5,2), "Degenerate triangle exists")
check.expect("tri-6: s2+s3==s1", is_triangle(5,3,2), "Degenerate triangle exists")
check.expect("tri-7: s3 > s1+s2", is_triangle(2,3,8), "No triangle exists")
check.expect("tri-8: s2 > s1+s3", is_triangle(3,8,2), "No triangle exists")
check.expect("tri-9: s1 > s2+s3", is_triangle(8,2,3), "No triangle exists")
