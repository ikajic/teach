## Tutorial 2

import check


## Question 5
## Write a function gcd which consumes 2 positive integers, a and b,  
## and returns the greatest common divisor of a and b.  

def divisor_from(???):
    ''' returns greatest divisor of a and b which is at most d
    
        divisor_from: ???
        requires: ???
    '''
    ???    
    
    
def gcd(a,b): 
    '''returns greatest common divisor of a and b
    
       gcd: ???
       requires: ???
       
       Examples: 
       gcd(10,14) => 2
       gcd(80,20) => 20
    '''
    ???


# Tests
check.expect("div1: 1,1", gcd(1,1), 1)
check.expect("div2: 1,12", gcd(1,12), 1)
check.expect("div3: 14,10", gcd(14,10), 2)
check.expect("div4: 10,14", gcd(10,14), 2)
check.expect("div5: 20,80", gcd(20,80), 20)
check.expect("div6: 42,42", gcd(42,42), 42)
check.expect("div7: 17*3, 17*4", gcd(17*3, 17*4), 17)
check.expect("div8: 167,109", gcd(167,109), 1)
check.expect("div9: 17*113, 151*3", gcd(17*113, 151*3), 1)
