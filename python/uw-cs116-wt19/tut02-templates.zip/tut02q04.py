## Tutorial 2

import check

## Question 4

## Write a function three_of_a_kind that consumes 4 
## integers, and produces true if exactly three of them 
## are equal, false otherwise.

def three_of_a_kind(d1,d2,d3,d4):
    '''returns True if exactly three of d1,d2,d3,d4 are equal
       and False otherwise. 
       
       three_of_a_kind: ???
       
       Examples: 
       three_of_a_kind(10,10,10,10) => False
       three_of_a_kind(2,3,2,2) => True
       three_of_a_kind(2,3,-1,2) => False
    '''
    ???


# Tests
check.expect("3-1: four of a kind", three_of_a_kind(10,10,10,10), False)
check.expect("3-2: three of a kind", three_of_a_kind(-5,-5,-5,2), True)
check.expect("3-3: three of a kind", three_of_a_kind(2,3,2,2), True)
check.expect("3-4: three of a kind", three_of_a_kind(0,0,-1,0), True)
check.expect("3-6: three of a kind", three_of_a_kind(5,1,1,1), True) 
check.expect("3-7: not three of a kind", three_of_a_kind(2,3,-1,2), False)
check.expect("3-8: not three of a kind", three_of_a_kind(8,0,0,8), False)
check.expect("3-9: not three of a kind", three_of_a_kind(2,3,-1,-8), False)
