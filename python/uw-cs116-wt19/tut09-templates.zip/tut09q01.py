## Tutorial 9

import check

## Dictionaries
## Question 1
# Write a function list_multiples that consumes a string s and
# returns a list in alphabetical order containing every character 
# in s that appears more than once. Use dictionaries.
# Examples:
# list_multiples("abcd") => []
# list_multiples("bacaba") => ["a", "b"]
# list_multiples("gtddyucaadsa") => ["a", "d"]


def list_multiples(s):
    '''
    returns a list containing every character in s which appears more than once, 
     in alphabetical order.
     
    list_multiples: Str -> (listof Str)
    
    Examples:
    list_multiples("") => []
    list_multiples("abc") => []
    list_multiples("bacaba") => ['a', 'b']
    '''
    ???


# Tests:	
check.expect("Q1t1",list_multiples(""),[])
check.expect("Q1t2",list_multiples("a"),[])
check.expect("Q1t3",list_multiples("ab"),[])
check.expect("Q1t4",list_multiples("abb"),["b"])
check.expect("Q1t5",list_multiples("bbaaarr"),["a","b","r"])
check.expect("Q1t6",list_multiples("gtddyucaadsa"),["a","d"])
