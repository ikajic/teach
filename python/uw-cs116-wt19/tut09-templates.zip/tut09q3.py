## Tutorial 9

import check

# Note to students attending tutorials:
#
# Purpose, contract & co. have been removed from solution templates to shorten
# this very long code for clarity, refer to solutions at the course website for
# the complete version ٩(^‿^)۶

class Student:

    def __init__(self, full_name, fac, prog, yr, titles):
        self.name = full_name
        self.faculty = fac
        self.program = prog        
        self.year = yr
        self.courses = titles

    def __eq__(self, other):
        if isinstance(other, Student):
            return self.name == other.name and \
                   self.faculty == other.faculty and \
                   self.year == other.year and \
                   self.program == other.program and \
                   self.courses == other.courses
        else:
            return False

    def __repr__(self):
        s = "{} ({}, {}, {},".format(self.name, self.faculty,
                self.program, self.year)
        s += " {})".format(self.courses)
        
        return s


    ###############
    ## Question 3 #
    ###############
    def add_courses(self, loc):
        pass
    
# Examples of student Objects    
Nicole_V = Student("Nicole Velocci", "Mathematics", "Statistics", 2, 
        ["ENGL 109", "MATH 237"])
Paul_S = Student("Paul Shen", "AHS", "Health Studies", 2, 
        ["MATH 106", "CS 234", "CS 200", "HLTH 273", "ECON 101"])
Steve_Z = Student("Steve Zhang", "Arts", "Psychology", 2, 
        ["PSYCH 207", "PSYCH 261", "PSYCH 202"])
Jason_A = Student("Jason Arl", "Mathematics", "Honours Mathematics", 2, 
        ["MATH 235", "MATH 237", "STAT 231"])
Tyler_H = Student("Tyler Hall", "Mathematics", "Mathematical Physics", 1,
                  ["MATH 136", "MATH 148", "STAT 230", "ENGL 119", "CHEM 121"])
Kyle_H = Student("Kyle Hauck", "Mathematics", "Applied Mathematics", 3,
                 ["AMATH 351", "AMATH 363", "AMATH 342", "STAT 332"])
Logan_S = Student("Logan Stanley", "Science","Chemistry", 1, 
                  ["CHEM 120", "MATH 127", "PHYS 111"])
Liza_W = Student("Liza Wang", "Engineering", "Software Engineering", 3,
                 ["BUS 121", "CS 343","CS 450"])
Dan_W = Student("Dan Wolczuk", "Mathematics", "Pure Mathematics", 1,
                ["MATH 148", "MATH 146", "CS 116"])

print('\n')
check.set_screen("Paul Shen is currently taking 6 course(s).")
check.expect("Q3 add-courses-1", Paul_S.add_courses(["HLTH 230"]), None)
check.expect("Q3 add-courses-1 - courses list", Paul_S.courses, 
    ["MATH 106", "CS 234", "CS 200", "HLTH 273", "ECON 101", "HLTH 230"])
check.set_screen("Nicole Velocci is currently taking 2 course(s).")
check.expect("Q3 add-courses-2", Nicole_V.add_courses([]), None)
check.expect("Q3 add-courses-2 - courses list", Nicole_V.courses, 
        ["ENGL 109", "MATH 237"])

###############
# Question 4: #
###############
group = [Jason_A, Dan_W, Liza_W, Kyle_H, Logan_S, Tyler_H, Paul_S]

def organize_by_year(loS):
    pass

# Add tests for function
print('\n')
check.expect("Q4 organize-empty", organize_by_year([]), {})
check.expect("Q4 organize-empty", organize_by_year([Paul_S]), {2:['Paul Shen']})

L = [Paul_S, Nicole_V, Dan_W]
check.expect("Q4 organize-typical", organize_by_year(L), 
             {1: ["Dan Wolczuk"], 2:['Paul Shen', 'Nicole Velocci']})


###############
# Question 5: #
###############

def is_same_faculty(loS):
    pass

print('\n')
check.expect("Q5 is_same: one student", is_same_faculty([Nicole_V]), True)
check.expect("Q5 is_same: all same", is_same_faculty([Nicole_V, Dan_W]), True)
check.expect("Q5 is_same: different", is_same_faculty([Paul_S, Logan_S]), False)
