## Tutorial 9

import check

## Dictionaries

## Question 2
# Write a function xor that consumes two dictionaries (d1 and d2)
# and returns a dictoinary.
# The returned dictionary will contain all the keys that appear
# in exactly one of d1 or d2 (but not both).
# The value associated with each key will be the same as the one
# found in the original dictionary.
# Examples:
# d1 = {1:'a', 2:'b', 3:'c', 4:'d'}
# d2 = {5:'e', 6:'f', 7:'g', 8:'h'}
# d3 = {5:'q', 6:'l', 7:'c', 8:'e'}
# xor(d1, d2) => {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g', 8:'h'}
# xor(d2, d3) => {}

# dictionaries used for testing
d1 = {1:'a', 2:'b', 3:'c', 4:'d'}
d2 = {5:'e', 6:'f', 7:'g', 8:'h'}
d3 = {5:'q', 6:'1', 7:'c', 8:'e'}
d4 = {1:'m', 5:'n', 3:'o', 7:'p'}


def xor(d1,d2):
    '''
    returns a dictionary that has each key/value pair such that the key is in 
     exactly one of d1 or d2 (not both).
     
    xor: (dictof X Y) (dictof Z W) -> (dictof (Anyof X Z) (Anyof Y W))
    
    Examples:
    xor(d1, d2) => {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g', 8:'h'}
    xor(d2, d3) => {}
    '''
    ???

# Tests:
check.expect("Distinct keys", xor(d1, d2), {1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g', 8:'h'})
check.expect("Same keys", xor(d2, d3), {})
check.expect("Mixed keys", xor(d1, d4), {2:'b', 4:'d', 5:'n', 7:'p'})
