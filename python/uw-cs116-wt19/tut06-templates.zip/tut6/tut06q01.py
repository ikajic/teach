## Tutorial 6 Midterm Review
# Source: Coding Bat, http://codingbat.com/prob/p118406

import check
import math

# Question 1 (Module 2 - Conditionals)
# Let's say we have large bricks that are 5 inches in length and
# small bricks that are 1 inch in length.

# Write a function called enough_bricks which has three parameters:
# small, the number of small bricks,
# large, the number of large bricks and
# goal, the length of a row we want to build.
# enough_bricks returns True if you can create a row of length goal
# with the number of small and large bricks, False otherwise.
# Examples:
# enough_bricks(3,1,8) => True
# enough_bricks(3,1,9) => False


# constants:
large_length = 5
small_length = 1

# enough_bricks(small, large, goal) returns True if the number
#   of small bricks, small, and the number of large bricks,
#   large, are enough to cover the row of length goal, False
#   otherwise.
# enough_bricks: ???? -> ????
# Examples:
# enough_bricks(3,1,8) => True
# enough_bricks(3,1,9) => False

def enough_bricks(small, large, goal):
    pass

# Tests:
check.expect("Q1T1", enough_bricks(3,1,8), True)
check.expect("Q1T2", enough_bricks(3,1,9), False)
check.expect("Q1T3", enough_bricks(3,2,10), True)
check.expect("Q1T4", enough_bricks(0,3,10), True)
check.expect("Q1T5", enough_bricks(40,1,46), False)
check.expect("Q1T6", enough_bricks(20,4,39), True)
check.expect("Q1T7", enough_bricks(1000000,1000,1000100), True)
check.expect("Q1T8", enough_bricks(2,1000000,100003), False)