## Tutorial 6 Midterm Review

import check
import math

# Question 4 (Module 5 - Accumulative and Generative Recursion)
# Write an accumulatively recursive function find_all that
# consumes a list of strings lst and a string s, and returns
# the list of indices of positions in lst with string s. Recall
# that the first position in a list has index 0.
# For example,
# find_all(["a","v","d","v"], "v") => [1,3]
# find_all(["a","v","d","v"], "q") => []

## Accumulative Recursion Solution
# find_all_acc(lst,s,pos,ans_so_far) returns a list of
#   natural numbers that are the indices of positions
#   where the string s occurs in the list of strings,
#   lst. ans_so_far keeps track of the list of indices
#   so far, and pos keeps track of the position to check.
# find_all_acc: ???? -> ????

def find_all_acc(lst, s, pos, ans_so_far):
    ????

# find_all(lst,s) returns a list of natural numbers that are
#   the indices of positions where the string s occurs in the
#   list of strings, lst.
# find_all: ???? ???? -> ????
# Examples:
# find_all([], "") => []
# find_all(["a","v","d","v"], "v") => [1,3]

def find_all(lst, s):
    return find_all_acc(lst, s, ????, ????) 

# Tests:
check.expect("Q4T1", find_all(["a","v","d","v"], "v"), [1,3])
check.expect("Q4T2", find_all(["a","v","d","v"], "q"), [])
check.expect("Q4T3", find_all([], ""), [])
check.expect("Q4T4", find_all(["word"], "word"), [0])
check.expect("Q4T5", find_all(["word"], "wrod"), [])
check.expect("Q4T6", find_all(["empty", "lst", "str", "str", "srt"], "str"), [2,3])
