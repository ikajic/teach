## Tutorial 6 Midterm Review

import check
import math

# Question 3b (Module 4 - Lists)
# Write a function modify_multiples that consumes a list of natural numbers (called numbers)
# and a positive natural number (called n), and mutates numbers so that all multiples of n
# are set to 0. The function returns None. 


# modify_from(numbers, n, pos) changes all 
#   multiples of n in numbers to 0, starting from 
#   position pos to the end of numbers
# Effects: mutates numbers
# modify_from: ???? -> ????
# requires: ????

def modify_from(numbers, n, pos):
    ????

# modify_multiples(numbers, n) modifies numbers, so that
#   all multiples of n are replaced by 0.
# Effects: ????
# modify_multiples: ????
# requires: ???
# Examples: 
# if L = [], after calling modify_multiples(L, 5), 
#   L is still []
# if L = [2,5,1,4,0,-6,11], after calling modify_multiples(L,2),
#   L = [0,5,1,0,0,0,11].

def modify_multiples(numbers, n):
    modify_from(numbers, n, ????)
    

L = []
check.expect("Q3b-empty list", ????, ????)
check.expect("Q3b-empty list (still empty)", ????, ????)

L = [5]
check.expect("Q3b-len=1, multiple of 5", , ????, ????)
check.expect("Q3b-len=1 (now contains 0)", , ????, ????) 

L = [5]
check.expect("Q3b-len=1, not a multiple", ????, ????)
check.expect("Q3b-len=1 (unchanged)", ????, ????)

L = [2,5,1,4,0,-6,11]
check.expect("Q3b-typical", ????, ????)
check.expect("Q3b-typical (changed)", , ????, ????)