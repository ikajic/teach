## Tutorial 6 Midterm Review

import check
import math

# Question 3A (Module 4 - Lists)
# Write a function multiples_of that consumes a list of natural
# numbers (called numbers) and a positive natural number (called
# n), and returns a list containing all entries in numbers which
# are multiples of n.
# The produced list must be in the same relative order as numbers.
# Write this function first with explicit recursion, then with
# abstract list functions.
# For example,
# multiples_of([], 4) => []
# multiples_of([18,5,19,21,300,0,4], 3) => [18,21,300,0]

# multiples_acc(numbers, n, lst_so_far) returns a list of 
#   natural numbers in the relative order as numbers, where
#   the returnsd list only contains those numbers that are
#   multiples of n, and lst_so_far keeps track of the list
#   of multiples of n so far.
# multiples_acc: ????
# requires: ????

def multiples_acc(numbers, n, lst_so_far):
    if numbers == []:
        return ????
    elif ????:
        return multiples_acc(????)
    else:
        return multiples_acc(????)

# multiples_of(numbers, n) returns a list of natural numbers in
#   the relative order as numbers, where the porudced list only
#   contains those numbers that are multiples of n
# multiples_of: ???? ???? -> ????
# requires: ????
# Examples:
# multiples_of([], 4) => []
# multiples_of([18,5,19,21,300,0,4]) => [18,21,300,0]

def multiples_of(numbers, n):
    return multiples_acc(numbers, n, ????)

# Tests:
check.expect("Q3T1", multiples_of([],4), [])
check.expect("Q3T2", multiples_of([10],2), [10])
check.expect("Q3T3", multiples_of([10],7), [])
check.expect("Q3T4", multiples_of([18,5,19,21,300,0,4],3), [18,21,300,0])
check.expect("Q3T5", multiples_of([17,11,107,53,2],4), [])
check.expect("Q3T6", multiples_of([10,8,4,6,18],2), [10,8,4,6,18])