## Tutorial 4

import check
import math


## Question 3
## a) Write a function flip_colour that takes in a card, c, and 
##    mutates the suit of that card to a different colour: if c
##    is a heart, it is mutated to a spade (and vice versa), while 
##    if c is a club, it is mutated to a diamond (and vice versa).

# a)
# example definitions:
diamond4 = [4,"diamonds"]
heart3 = [3,'hearts']


def flip_colour(c):
    # Note that we cannot save c[1] as a local variable because it will
    # not alias the way we need; draw a memory diagram if this is unclear
    '''mutates the suit of c: hearts becomes spades (and vice versa) and 
       clubs becomes diamonds (and vice versa)
    
       Effects: the suit field of c is mutated
    
       flip_colour: Card -> None
    
       Examples:
       If flip_colour (diamond4) is called then diamond4 will equal [4,'clubs']
       If flip_colour (heart3) is called then heart3 will equal [3,'spades']
     '''
     ???
     
# Tests:
club4 = [4,"clubs"]
check.expect("flip_colour Test 1 (function)", flip_colour(club4), None)
check.expect("flip_colour Test 1 (card)", club4, [4,'diamonds'])

diamond4 = [4,"diamonds"]
check.expect("flip_colour Test 2 (function)", flip_colour(diamond4), None)
check.expect("flip_colour Test 2 (card)", diamond4, [4,'clubs'])

spade3 = [3,'spades']
check.expect("flip_colour Test 3 (function)", flip_colour(spade3), None)
check.expect("flip_colour Test 3 (card)", spade3, [3,'hearts'])

heart3 = [3, 'hearts']
check.expect("flip_colour Test 4", flip_colour (heart3), None)
check.expect("flip_colour Test 4", heart3, [3,'spades'])
