## Tutorial 4

import check
import math

## Question 5
## Write a function sanitize that consumes a string, s, and produces a
## similar string but with any non-alphanumeric characters removed.
## For example: sanitize("@Test@") => "Test"
#   DO NOT use explicit recursion.

       
def sanitize(s):
    '''returns a string like s, but with all non-alphanumeric characters 
       removed from it.
       
       sanitize: Str -> Str
       
       Examples:
       sanitize("") => ""
       sanitize("Test") => "Test"
       sanitize("@Test@") => "Test"
       sanitize("!!@#$!") => ""    
    '''
    ???

# Tests:
check.expect("sanitize1", sanitize(""), "")
check.expect("sanitize2", sanitize("Test"), "Test")
check.expect("sanitize3", sanitize("Test!"), "Test")
check.expect("sanitize4", sanitize("Hello World"), "HelloWorld")
check.expect("sanitize5", sanitize("!@#$@TEST()()()123!@#!4"), "TEST1234")
check.expect("sanitize6", sanitize("!@#$%^($)*@"), "")
