## Tutorial 4

import check
import math


## Questions 1, 2, and 3 use the following data definition:
## A Card is a list of length 2 where 
## - the first item is an integer between 1 and 13, inclusive, 
##   representing the value of the card, and
## - the second item is a string ("hearts", "spades", "clubs", 
##   or "diamonds") representing the suit of the card.
## Example: [1, "hearts"] represents the ace of hearts


## Question 1
## Write a function create_cards that consumes a list of card values 
## (integers between 1 and 13), and a list of suite values (one of 
## the four suit strings), and produces a list of cards created 
## pair-wise from the consumed lists (values and suits).
## Example: create_cards([4,1,10], ["hearts","diamonds","clubs"]) 
##          => [[1, "diamonds"], [4,"hearts"],[10, "clubs"] ].

def create_cards(values, suits):
    '''returns a sorted list of cards with indicated values and suits. 
       The produced list has the same length as values and suits.
       
       create_cards: (listof Nat) 
                     (listof (anyof "hearts" "spades" "clubs" "diamonds")) 
                     -> (listof Card)
       Requires: len(values) == len(suits)
                 1 <= all elements of values <= 10
                 
       Examples: 
       create_cards([],[]) => []
       create_cards([4,1,10], ['hearts', 'diamonds', 'clubs']) 
           => [[1, 'diamonds'],[4,'hearts'], [10, 'clubs'] ]
    '''
    ???



check.expect("cc1", create_cards([],[]), [])
check.expect("cc2", create_cards([4], ['hearts']), [ [4,'hearts'] ])
L = ['hearts', 'spades', 'spades', 'diamonds', 'clubs', 'hearts']
check.expect("cc3", create_cards([6,2,5,4,3,1], L), 
             [ [6, 'hearts'], [2,'spades'], [5,'spades'], [4, 'diamonds'], [3,'clubs'], [1,'hearts']])
