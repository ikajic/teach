## Tutorial 4

import check
import math

## Question 4
## Write a function modify_list that consumes a list of integers (nums) 
## and a single integer (n). The function produces None, but mutates 
## the list in the following way:
## - If n does not appear in nums then add it to the end of nums.
## - If n appears once, then remove n from nums
## - If n appears at least twice, remove the first and last occurrences of n


def index_of_last(vals, n, position):
    '''returns the index of the last occurrence of n in vals[:position+1], where
       0 <= position < len(vals)-1, and n occurs at least once in this range.
       
       index_of_last: (listof Int) Int Int -> Int
       Requires: position >= 0
    '''
    ???

def modify_list(nums, n):
    '''mutates nums to reflect the following conditions: 
       If n does not appear in nums, it is added to the end of it. If n appears 
       exactly once in the list, then remove it from nums. If n appears two of
       more times in nums, the first and last occurrences of n are removed.
       
       Effects: nums is mutuated
       
       modify_list: (listof Int) Int -> None
       
       Examples: 
       * if L = [], modify_list(L,10) => None, and L = [10]
       * if L = [1,2,3], modify_list(L,10) => None, and L = [1,2,3,10]
       * if L = [1,2,3,4], modify_list(L,4) => None, and L = [1, 2, 3]
       * if L = [1,5,2,1,7,1,9], modify_list(L,1) => None, and L = [5,2,1,7,9]
    '''
    ???

# Tests:
L = []
check.expect("ml-1", modify_list(L, 3), None)
check.expect("m1-1(L)", L, [3])
check.expect("ml-2", modify_list(L,3), None)
check.expect("ml-2(L)", L, [])
L = [4,4]
check.expect("ml-3", modify_list(L,4), None)
check.expect("ml-3(L)", L, [])
L = [-1,-1,-1]
check.expect("ml-4", modify_list(L,-1), None)
check.expect("ml-4(L)", L, [ -1])
L = [2,4,3,2,5,7,6,2,5,7]
check.expect("ml-5", modify_list(L,2), None)
check.expect("ml-5(L)", L, [4,3,2,5,7,6,5,7])
check.expect("ml-6", modify_list(L,7), None)
check.expect("ml-6(L)", L, [4,3,2,5,6,5])
check.expect("ml-7", modify_list(L,0), None)
check.expect("ml-7(L)", L, [4,3,2,5,6,5,0])

