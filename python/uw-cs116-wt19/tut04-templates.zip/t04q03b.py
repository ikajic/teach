## Tutorial 4

import check
import math


## Question 3
## a) Write a function flip_colour that takes in a card, c, and 
##    mutates the suit of that card to a different colour: if c
##    is a heart, it is mutated to a spade (and vice versa), while 
##    if c is a club, it is mutated to a diamond (and vice versa).

## b) Write a function flip_hand that reads in a list of cards (hand),
##    and mutates the suit of each card in the list so that their 
##    colours are flipped in the same way as in flip_colour.

# a)
# example definitions:
diamond4 = [4,"diamonds"]
heart3 = [3,'hearts']


def flip_colour(c):
    # Note that we cannot save c[1] as a local variable because it will
    # not alias the way we need; draw a memory diagram if this is unclear
    '''mutates the suit of c: hearts becomes spades (and vice versa) and 
       clubs becomes diamonds (and vice versa)
    
       Effects: the suit field of c is mutated
    
       flip_colour: Card -> None
    
       Examples:
       If flip_colour (diamond4) is called then diamond4 will equal [4,'clubs']
       If flip_colour (heart3) is called then heart3 will equal [3,'spades']
     '''    
    if c[1] == 'hearts':
        c[1] = 'spades'
    elif c[1] == 'spades':
        c[1] = 'hearts'
    elif c[1] == 'clubs':
        c[1] = 'diamonds'
    elif c[1] == 'diamonds':
        c[1] = 'clubs'

# part b:
def flip_hand_from(hand, position):
    '''mutates the suit of c: hearts becomes spades (and vice versa) and clubs
       becomes diamonds (and vice versa)
       
       Effects: the suit field of c is mutated
       
       flip_colour: Card -> None
       
       Examples:
       If flip_colour (diamond4) is called then diamond4 will equal [4,'clubs']
       If flip_colour (heart3) is called then heart3 will equal [3,'spades']
     '''    
    ???        
        
      
def flip_hand(hand):
    '''mutates the suit of each card in hand: hearts becomes spades 
       (and vice versa) and clubs becomes diamonds (and vice versa)
       
       Effects: Mutates the suit field of each card in the list
       
       flip_hand: (listof Card) -> None
       
       Examples:
       If lst = [] and flip_hand_alt(lst) is called, lst becomes []
       If lst = [[5, 'hearts'], [1, 'diamonds']] and flip_hand_alt(lst) 
           is called,lst becomes [[5, 'spades], [1, 'clubs']]  
    '''    
    ???

# Tests:
lst = []
check.expect("flip_hand Test 1 (function)", flip_hand(lst), None)
check.expect("flip_hand Test 1 (list)", lst, [])

lst = [[7, 'spades']]
check.expect("flip_hand Test 2 (function)", flip_hand(lst), None)
check.expect("flip_hand Test 2 (list)", lst, [[7, 'hearts']])

lst = [[6,'clubs'], [9,'hearts'], [2,'diamonds']]
check.expect("flip_hand Test 3 (function)", flip_hand(lst), None)
check.expect("flip_hand Test 3 (list)",
             lst,
             [[6,'diamonds'], [9,'spades'], [2,'clubs']])
