## Tutorial 4

import check
import math


## Questions 1, 2, and 3 use the following data definition:
## A Card is a list of length 2 where 
## - the first item is an integer between 1 and 13, inclusive, 
##   representing the value of the card, and
## - the second item is a string ("hearts", "spades", "clubs", 
##   or "diamonds") representing the suit of the card.
## Example: [1, "hearts"] represents the ace of hearts


## Question 2
## Write a function choose_by_colour that consumes a list of cards 
## (hand) and a string "red" or "black" (colour) and produces a list 
## of the values of the cards in hand of the appropriate colour (spades 
## and clubs are "black", hearts and diamonds are "red"). 
## Example: choose_by_colour([[1,'hearts'], [9, 'spades'], [3,'diamonds']], 
##                           'red')=> [1,3]
## Write this function twice. First, use explicit recursion. Then, 
## use abstract list functions.

# Solution 1 - Structural Recursion:
def choose_by_colour(hand, colour):
    '''returns the list of values of the cards in hand which are of 
       the specified colour ('red' or 'black')
    
       choose_by_colour: (listof Card) (anyof 'red' 'black') -> (listof Nat)
       
       Examples: 
       choose_by_colour([], 'red') => []
       choose_by_colour([[1,'hearts'], [9, 'spades'], [3,'diamonds']], 'red') 
           => [1,3]
    '''
    ???

# Constants for testing    
hearts3  = [3, 'hearts']
clubs2 = [2, 'clubs']
diamonds4 = [4, 'diamonds']
spades9 = [9, 'spades']

check.expect("cbc-t1", choose_by_colour([], 'red'), [])
check.expect("cbc-t2", choose_by_colour([hearts3], 'red'), [3])
check.expect("cbc-t3", choose_by_colour([clubs2], 'red'), [])
check.expect("cbc-t4", choose_by_colour([diamonds4], 'red'), [4])
check.expect("cbc-t5", choose_by_colour([spades9], 'red'), [])
check.expect("cbc-t6", choose_by_colour([hearts3], 'black'), [])
check.expect("cbc-t7", choose_by_colour([clubs2], 'black'), [2])
check.expect("cbc-t8", choose_by_colour([diamonds4], 'black'), [])
check.expect("cbc-t9", choose_by_colour([spades9], 'black'), [9])
check.expect("cbc-t10", choose_by_colour([hearts3, clubs2, diamonds4, spades9], 'red'), [3,4])
check.expect("cbc-t11", choose_by_colour([hearts3, clubs2, diamonds4, spades9], 'black'), [2,9])

