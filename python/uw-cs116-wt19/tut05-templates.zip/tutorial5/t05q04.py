import check

# Question 4

# skip_value(L) returns the skip value of a list of positive integers L.
# skip_value: ???? -> ????
# requires: ????
# Examples:
# skip_value([]) => 0
# skip_value([1,1,1]) => 3


def skip_value(L):
    ????


# Tests
check.expect("Skip-T1", skip_value([]), 0)
check.expect("Skip-T2", skip_value([1, 1, 1]), 3)
check.expect("Skip-T3", skip_value([2, 100, 1]), 2)
