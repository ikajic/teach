import check

# Question 1

# list_to_num_acc(dig, num_so_far) adds the digits in dig to the end of
#   num_so_far, eventually returns natural number, which is the newest
#   num_so_far
# list_to_num_acc: ???? ???? -> ????


def list_to_num_acc(dig, num_so_far):
    ????

# list_to_num(digits) builds a number from its list of digits
# list_to_num: ???? -> ????
# requires: ????
#           ????
# Examples:
# list_to_num([9, 0, 8]) => 908
# list_to_num([8, 6]) => 86


def list_to_num(digits):
    ????


# Tests
check.expect("Q1T1", list_to_num([9, 0, 8]), 908)
check.expect("Q1T2", list_to_num([0]), 0)
check.expect("Q1T3", list_to_num([8, 6]), 86)
