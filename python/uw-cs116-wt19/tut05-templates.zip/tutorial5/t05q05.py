import check

# Question 5

# constants for testing
t0 = [[1]]
t1 = [[1, 2, 3]]
t2 = [[1], [2], [3]]
t3 = [[1, 2], [3, 4], [5, 6], [7, 8]]
t4 = [[1, 2, 3, 4],
      [5, 6, 7, 8],
      [9, 10, 11, 12],
      [13, 14, 15, 16],
      [17, 18, 19, 20]]

# sum_cols_from(t, col) returns the list containing the sum of all entries in
# each column of t, starting from column col
# sum_cols_from: ??? -> ???
# requires: ????


def sum_cols_from(t, col):
    ????

# sum_columns(t) returns the list containing the sum of all entries in each
#   column of t
# sum_columns: ???? -> ????
# Examples:
# * sum_columns([1]] = [1]
# * sum_columns([[1,2], [3,4], [5,6], [7,8]]) => [16,20]


def sum_columns(t):
    ????

# Tests
check.expect("t0", sum_columns(t0), [1])
check.expect("t1", sum_columns(t1), [1, 2, 3])
check.expect("t2", sum_columns(t2), [6])
check.expect("t3", sum_columns(t3), [16, 20])
check.expect("t4", sum_columns(t4), [45, 50, 55, 60])
