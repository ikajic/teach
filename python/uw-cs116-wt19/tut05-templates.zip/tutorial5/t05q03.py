import check

# Question 3

# is_balanced(s) returns True if s is bracket-balanced, and False if not.
# is_balanced: ???? -> ????
# Examples:
# is_balanced("") => True
# is_balanced("NO)PE") => False


def is_balanced(s):
    ????


# Tests
check.expect("T1", is_balanced(""), True)
check.expect("T2", is_balanced("(hi)"), True)
check.expect("T3", is_balanced("NO)PE"), False)
check.expect("T4", is_balanced("{no]"), False)
check.expect("T5", is_balanced("wrong{}thing"), True)
check.expect("T6", is_balanced("[cool(brackets)]"), True)
check.expect("T7", is_balanced("{[([{()}])]}"), True)
