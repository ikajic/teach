import check

# Question 6

# smaller(s) returns the single digit obtained by repeatedly removing the
#   larger of the first or last digits in the list, or the last one if
#   they are the same.
# smaller: ???? -> ????
# requires: ????
#           ????
# Examples:
# smaller("1") => "1"
# smaller("5284") => "2"


def smaller(s):
    ????


# Tests
check.expect("T1", smaller("1"), "1")
check.expect("T2", smaller("5284"), "2")
check.expect("T3", smaller("123456"), "1")
check.expect("T4", smaller("99999"), "9")
check.expect("T5", smaller("12121"), "1")
check.expect("T6", smaller("9321123"), "1")
