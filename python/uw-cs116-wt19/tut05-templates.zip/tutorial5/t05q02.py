import check

# Question 2

# count_max_acc(????) returns occurences + the number
#  of times max_so_far appears in lst if max_so_far >= maximum value in lst;
#  or returns the number of time the maximum values in lst occurs if
#  max_so_far < maximum value in lst.
# count_max_acc: ???? -> ????


def count_max_acc(????):
    ????


# count_max(alon) returns the number of occurrences of
#  the largest number in alon.
# count_max: (listof Int) -> Nat
# requires: alon is non empty
# Examples:
# count_max([-4]) => 1
# count-max([1, 3, 5, 4, 2, 3, 3, 3, 5]) => 2


def count_max(alon):
    return count_max_acc(????)


# Tests for count_max
check.expect("Q2T1", count_max([-4]), 1)
check.expect("Q2T2", count_max([4, 4, -1]), 2)
check.expect("Q2T3", count_max([-7, -8, 12]), 1)
check.expect("Q2T4", count_max([1, 3, 5, 4, 2, 3, 3, 3, 5]), 2)
