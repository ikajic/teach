## Tutorial 3

import check
import math

## Question 2
## Write a function create_date that consumes nothing, but
## takes keyboard input. The program has three prompts:
## "Enter the year: ", "Enter the month: " and "Enter the day: ".
## The function then produces a date in the form "dd/mm/yyy",
## where dd is a 2 digit number (between 01 and 31, depending
## on the month, mm is a 2 digit number (between 01 and 12),
## and yyyy is a 4 digit integer.
## For example,
## create_date()
## Enter the year: 1996
## Enter the month: 06
## Enter the day: 17
## => "17/06/1996"
## Use string methods and string formatting (using {}) to
## complete this question



def create_date():
    '''
    returns the date in the form "dd/mm/yyyy" by prompting the user for three strings,
      reads in the year, the month and the day respectively for each string.
    Effects: Prints three prompts to the user, reads in a year, a month and a day.
    
    create_date: ???
    
    Examples:
    If the user enters "1996", "06", "17" when create_date() is
      called, "17/06/1996" is returned
    If the user enters "2016", "05", "25" when create_date() is
      called, "25/05/2016" is returned
    '''
    ???

# Tests
???
