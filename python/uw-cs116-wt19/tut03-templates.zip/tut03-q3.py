## Tutorial 3

import check
import math

## Question 3
## Write a function fill_the_string that consumes a non-empty
## string s and a positive integer n, and which makes an n-letter
## string that consists of copies of s, where the last one is
## perhaps a partial copy.
## For example,
## fill_the_string("love", 12) => "lovelovelove"
## fill_the_string("truth", 12) => "truthtruthtr"


def fill_the_string(s, n):
    '''
    returns an n-letter string made up of copies of s; 
      the final copy might not be a complete copy.
    fill_the_string: ???

    requires: ???

    Examples:
      fill_the_string("love", 12) => "lovelovelove"
      fill_the_string("truth", 12) => "truthtruthtr"
    '''
    ???

# Tests:
check.expect("One full copy", fill_the_string("love", 4), "love")
check.expect("Three full copies", fill_the_string("love", 12), "lovelovelove")
check.expect("Full copies+partial copy", fill_the_string("truth", 12), 
             "truthtruthtr")
check.expect("Long full copies+partial copy", fill_the_string("love", 22), 
             "lovelovelovelovelovelo")

