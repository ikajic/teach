## Tutorial 3

import check
import math

## Question 1
## Write a function closest_integer that has no arguments, but instead 
## reads in a floating point number from console input with a prompt
## "Waht's the number?", and returns the closest integer to that number. 
## (This function rounds ties up, so that 
## closest_integer(0.5) is 1, while closest_integer(-0.5) is 0.
## DO NOT use round in your solution.)

#
# #
#
def closest_integer():
    '''
    returns the integer closest to the value entered
      by the user, always round 0.5 up to the next largest integer.
    Effects: Reads in a float from console input
    
    closest_integer: ??? -> ???

    Examples:
    If the user types in 0, closest_integer returns 0
    If the user types in 0.3, closest_integer returns 0
    if the user types in -1.5, closest_integer returns -1
    if the user types in -1.8, closest_integer returns -2
    if the user types in 1.8, closest_integer returns 2
    '''
    ???

# additional tests:
???
