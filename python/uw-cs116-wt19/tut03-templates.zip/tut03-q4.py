## Tutorial 3

import check
import math

## Question 4
## Write a recursive function <code>sum_up</code> that has no parameters but takes
## input from the keyboard. This function prompts the user with 
## "Enter the amount of numbers to sum: ", followed by "Enter an integer: "
## which will read input the amount of times as the number entered before.
## The function then prints a message "The sum is n", where n is the sum of 
## all the integers that were entered.</p> 
## Example:
## Enter the amount of numbers to sum: 4
## Enter an integer: 3
## Enter an integer: 56
## Enter an integer: 7
## Enter an integer: 8
## The sum is 74


def read_and_sum(???):
    '''
    returns the sum of input numbers by prompting messages and reads
      in a series of integers
    Effects: Prints prompts to the user and reads in a series of integers
    read_and_sum: ???
    '''
    ???


def sum_up():
    '''
    prints out a message with the sum of all input integers by prompting
      messages and reads in a series of integers, with the initial integer
      corresponding to the amount of integers to be summed
    Effects: Prints prompts to the user and reads in a series of integers,
      prints out a message with the sum of all input integers

    sum_up: ????

    Examples:
      If the user input is ["1', "1"], sum_up() prints "The sum is 1"
      If the user input is ["4", "3", "56", "7", "8"],
        sum_up() prints "The sum is 74"
    '''
    ???

# Tests
???
