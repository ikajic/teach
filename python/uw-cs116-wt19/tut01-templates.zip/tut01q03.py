## Tutorial 1

import check
import math

## Question 3
## The standard deviation of a set of numbers x_i is calculated as the
## the square root of the mean of the sums (x_i - x_mean)^2, where 
## x_mean is the arithmetic mean of the x_i values. For example, the 
## standard deviation of 3.2, 9.8, 6.3, 1.2, 3.3 is 3.00039997.

## Write a Python function std_dev that consumes five floating point
## numbers (x1,x2,x3,x4,x5) and produces their standard deviation.


def std_dev(x1, x2, x3, x4, x5):
    '''
    returns standard deviation of the values x1, x2, x3, x4, x5
    
    std_dev: ???
    
    Examples:
    std_dev(3.2, 9.8, 6.3, 1.2, 3.3) => 3.00039997
    std_dev(5.8, 5.8, 5.8, 5.8, 5.8) => 0.0
    '''
    ???
    return ???

# Tests for std_dev
check.within("Q3T1", std_dev(3.2, 9.8, 6.3, 1.2, 3.3), 3.00039997, 0.00001)
check.within("Q3T2", std_dev(5.8, 5.8, 5.8, 5.8, 5.8), 0.0, 0.00001)
check.within("Q3T3", std_dev(-3.0, 0.0, 7.0, 3.0, -7.0), 4.8166378, 0.00001)
