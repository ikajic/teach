## Tutorial 1

????

## Question 1
## Write a Python function create_acct_num that consumes a 3-digit
## number and produces the corresponding 4-digit number, in which the
## new last digit is remainder when the sum of the digits of the
## original number is divided by 7.

## For example,
##     create_account_number(778) => 7781
## because 7 + 7 + 8 = 22 and 22/7 has remainder 1


def create_account_number(acct):
    '''
    ???
    
    ???
    
    ??? 
    Examples:
    ???
    ???
    '''
    ???
    return new_acct

# Tests for create_account_number
???
???
