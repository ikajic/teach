## Tutorial 1

import check

## Question 2
## Write a Python function shipping_charges that calculates cost of
## shipping boxes. The function consumes:
##     - a handling charge,
##     - the cost per kg for shipping,
##     - the weight per box (assumed the same for all boxes), and
##     - the number of boxes to ship.
## The function adds in 13% tax, and returns the total
## cost.

## For example,
##     shipping_charges(10, 0.25, 10, 5) => 25.425

## Note that the value produced may not stored exactly. So, your test
## should not check for an exact value, but rather should check that
## your answer is very close to the expected value.

def shipping_charges(handling, charge_per_kg, weight_per_box, num_boxes):
    '''
    returns the total cost of shipping num_boxes, each weighing
        weight_per_box kg, at a charge of charge_per_kg. There is a
        handling charge applied, and a tax of 13% is added to everything.
    
    ???

    Examples:
    shipping_charges(10, 0.25, 10, 5) => 25.425
    shipping_charges(0, 100.0, 88, 0) => 0.0
    '''
    return total_cost

# Tests for shipping_charges:
check.???("Q2T1", shipping_charges(0, 100.0, 88, 0), 0.0, 0.0001)
check.???("Q2T2", shipping_charges(12, 0.0, 5, 89098), 13.56, 0.0001)
check.???("Q2T3", shipping_charges(10, 0.25, 10, 5), 25.425, 0.0001)
