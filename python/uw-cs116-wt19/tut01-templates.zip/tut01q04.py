## Tutorial 1

import check
import math

## Question 4
## Consider a basic smart phone plan that charges as follows:
##   * monthly charge $39.00
##   * $0.50 per phone minutes over 200 free "anytime" minutes
##   * $5.00 for each part of 150 MB of data over the first 100 MB used.

## For example, if you used 15 minutes of phone calls and 87 MB of
## data, your charge would be $39.00; if you used 250 minutes of phone
## calls and 500 MB of data, your charge would be $79.00 ($25.0 extra
## for the phone calls, and $15.0 extra for data).

## Write a Python function cell_charge that consumes two Nats (minutes
## and data) corresponding to the total number of phone minutes used
## and the amount of data used in a month, and produces the total
## phone bill for the month, including the basic monthly charge. 

## Do not perform any rounding on the result.

def cell_charge(minutes, data):
    '''
    returns the monthly charge for a cell plan with a basic charge of $39 plus 
      $0.50 per phone minutes used over 200 minutes plus $5 per 150 MB used
      (or part thereof) over 100 MB in the month
      
    cell_charge: ???
    
    Examples:
    cell_charge(15, 87) => 39.0
    cell_charge(250, 500) => 79.0
    '''
    ???
    return ???

# Tests for cell_charge
check.within("Q4T1", cell_charge(15, 87), 39.0, 0.00001)
check.within("Q4T2", cell_charge(200, 100), 39.0, 0.00001)
check.within("Q4T3", cell_charge(100, 200), 44.0, 0.00001)
check.within("Q4T4", cell_charge(100, 500), 54.0, 0.00001)
check.within("Q4T5", cell_charge(250, 50), 64.0, 0.00001)
check.within("Q4T6", cell_charge(250, 500), 79.0, 0.00001)
