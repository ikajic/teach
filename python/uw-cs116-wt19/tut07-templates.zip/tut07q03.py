## Tutorial 7 - Iteration

import check

## Question 3
# Write a Python function divisible_by_3 that consumes a Nat 
# (called n), and returns True if n is divisible by 3, and 
# False otherwise. You must use the following algorithm:
#  - The only numbers less than 10 that are divisible by 3
#    are: 0, 3, 6, 9
#  - A number is divisible by 3 if the sum of its digits is
#    also divisible by 3. If the sum of the digits of the 
#    number is greater than 10, calculate the sum of the 
#    digits of the sum, and repeat until you get a number
#    less than 10.

def divisible_by_3(n):
    '''
    divisible_by_3(n) returns True if n is divisible by 3,
        and False if not.
    
    divisible_by_3: Nat -> Bool
    
    Examples:
    divisible_by_3(6) => True
    divisible_by_3(137) => False
    '''
    ????



# Tests
check.expect("div3-0", divisible_by_3(0), True)
check.expect("div3-1", divisible_by_3(1), False)
check.expect("div3-2", divisible_by_3(2), False)
check.expect("div3-3", divisible_by_3(3), True)
check.expect("div3-4", divisible_by_3(4), False)
check.expect("div3-5", divisible_by_3(5), False)
check.expect("div3-6", divisible_by_3(6), True)
check.expect("div3-7", divisible_by_3(7), False)
check.expect("div3-8", divisible_by_3(8), False)
check.expect("div3-9", divisible_by_3(9), True)
check.expect("div3-10", divisible_by_3(10), False)
check.expect("div3-11", divisible_by_3(11), False)
check.expect("div3-27", divisible_by_3(27), True)
check.expect("div3-127", divisible_by_3(127), False)
check.expect("div3-99353118", divisible_by_3(99353118), True)
check.expect("div3-99353119", divisible_by_3(99353119), False)

