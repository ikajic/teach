## Tutorial 7 - Iteration

import check

## Question 1
# Write a function all_same_type that consumes a list,
# called lst, and returns True if all members of that
# list are of the same type, else False.
# For example:
# all_same_type([2, 5, 3]) => True
# all_same_type([2, 'R', 4.56]) => False

def all_same_type(lst):
    '''
    all_same_type(lst) returns True if all elements in
        lst are of the same type, and False otherwise
    
    all_same_type: (listof Any) -> Bool
    
    Examples:
    all_same_type([]) => True
    all_same_type(["a"]) => True
    all_same_type(["a", 1]) => False
    all_same_type(["a", "b"]) => True
    '''
    ???

# Tests
check.expect("Test 1", all_same_type([]), True)
check.expect("Test 2", all_same_type(["a"]), True)
check.expect("Test 3", all_same_type(["a",1]), False)
check.expect("Test 4", all_same_type(["a","b"]), True)
check.expect("Test 5", all_same_type([1,1.0]), False)
check.expect("Test 6", all_same_type([[1,2],['b','c']]), True)
check.expect("Test 7", all_same_type([1,2,3,4,5,6,7]), True)
check.expect("Test 8", all_same_type([1,2,'3',[4],'5',6,7]), False)  # q

