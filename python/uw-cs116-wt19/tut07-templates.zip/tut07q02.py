## Tutorial 7 - Iteration

import check


## Question 2
# Write a Python function max_even_sum that consumes a nonempty 
# list of lists of positive integers, lst. It computes the sum
# of the even integers in each sublist, and returns the largest 
# out of these sumes. If a sublist contains no even integers, 
# its sum is zero.
# For example:
# max_even_sum([[],[3],[2,4,6]]) => 12

def max_even_sum(lst):
    '''
        
    max_even_sum(lst) calculates the sum of even values in each
        row of lst, and produes the largest such sum. If a sublist
        cantains no even integers, its sum is 0.
    
    max_even_sum: (listof (listof Int)) -> Int
    requires: each element of lst is a list of integers which
                are >= 0 and lst is non-empty
    
    Examples: 
    max_even_sum([[]]) => 0
    max_even_sum([[3,1]]) => 0
    max_even_sum([[2],[7]]) => 2
    max_even_sum([[4,2,5],[9,8,9]]) => 8
    '''
    ???


# Tests
check.expect("Test 1", max_even_sum([[]]), 0)
check.expect("Test 2", max_even_sum([[1,7,3]]), 0)
check.expect("Test 3", max_even_sum([[2,4]]), 6)
check.expect("Test 4", max_even_sum([[2,3,4]]), 6)
check.expect("Test 5", max_even_sum([[2], [7,9], [4,4]]), 8)
check.expect("Test 6", max_even_sum([[4,2,5],[9,8,9],[2,3,4,99],[10]]),10)

