## Tutorial 7 - Iteration

import check

## Question 5
# Write a function called valid_input that consumes a string to be used 
# as the prompt, prompt,  a list of strings of valid inputs, valid,
# and a positive integer max_guess. 
# The function should continuously prompt the user for input until 
# the user enters a value in the list valid, and then returns that value,
# or print a message when maximum number of guess is reached. If the user 
# enters an invalid value, the function will let them know by printing: 
# "Invalid input. Try again." to the screen.  
# If maximum number of guess is reached, the function will 
# print "Maximum number of guess reached" and return None in this case.

# For example:
# If the user enters "6", "5",  and "3", 
# valid_input("Enter a digit < 5: ",
#	      ["0", "1", "2", "3", "4"], 5) => "3" 
# and the following is printed:
# Enter a digit < 5: 5
# Invalid input. Try again.
# Enter a digit < 5: 3
# Note: You may assume that the user enters input that is the correct type.


def valid_input(prompt, valid, max_guess):
    '''
    valid_input(prompt, valid, max_guess) returns the first string in valid
        entered by the user when prompted by prompt, or print message when max_guess
        number of guesses is reached.
    
    Effects: Prompts the user for type of data to enter, and reads
             in the choice. This process is repeated until the user
             enters one of the values in valid.
             print message when max_guess number of guesses is reached
    
    valid_input: Str (listof Str) Int -> (Anyof Str None)
    
    requires: valid is a non-empty list
              max_guess > 0
    
    Examples: valid_input("Will you pass CS116? ", ["yes","no"], max_guess)
              will return either "yes" or "no" or print message.
              valid_input("Who was Prime Minister in 2008? ", ['Harper'])
              will return "Harper" once it is entered by the user, or print
              message.

    '''
    ???


## Tests
check.set_input(["42"])
check.expect("Test 1", valid_input("What is the anser to the ultimate question? ", ["42"], 5), "42")

check.set_input(["no","five","9","cat","snow","Pi Day"])
check.set_screen("5x 'Invalid input. Try again.'")
check.expect("Test 2", valid_input("What day is March 14th? ", ["Pi Day"], 10), "Pi Day")

check.set_input(["yellow"])
check.set_screen(["Invalid input. Try again.", "Maximum number of guess is reached"])
check.expect("Test 3", valid_input("Name a colour on the Italian flag: ", ["green","white","red"], 1), None)

check.set_input(["yellow", "apple", "blue"])
check.set_screen(["Invalid input. Try again.", "Maximum number of guess is reached"])
check.expect("Test 4", valid_input("Name a colour on the Canadian flag: ", ["white","red"], 3), None)
