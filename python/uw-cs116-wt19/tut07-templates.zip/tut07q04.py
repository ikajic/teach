## Tutorial 7 - Iteration

import check


## Question 4
# Write a Python function make_list that consumes a natural
# number n and returns a list of strings. The returned list 
# will look like 
# ["", "1", "22", "333", "4444", "55555", ... , "nnnnn...nnnn"]
# where the last element is the number n repeated n times.

# For example:
# make_list(0) => [""]
# make_list(3) => ["", "1", "22", "333"]

def make_list(n):
    '''
    make_list(n) consumes a Nat, n, and returns a list of
        strings, "", "1", "22", ..., "nnnn...nn" (n times)
    
    make_list: Nat -> (listof Str)
    
    Examples:
    make_list(0) => [""]
    make_list(1) => ["", "1"]
    make_list(5) => ["", "1", "22", "333", "4444", "55555"]
    '''
    ????
    
# Tests
check.expect("Test 1", make_list(0), [""])
check.expect("Test 2", make_list(1), ["", "1"])
check.expect("Test 3", make_list(3), ["", "1", "22", "333"])
check.expect("Test 4", make_list(6), ["", "1", "22", "333", "4444", "55555", "666666"])


