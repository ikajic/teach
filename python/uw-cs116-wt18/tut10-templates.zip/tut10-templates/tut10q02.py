## Tutorial 10

import check

class CD:

    def __init__(self, artist, dur, los):
        '''
        [purpose]: Initializes a CD
        [fields]:
           * artist (artist's name) - Str
           * duration (duration of CD in seconds) - Int
           * songs (list of artist's songs) - (listof Str)
        '''
        self.artist = artist
        self.duration = dur
        self.songs = los
    
    def __repr__(self):
        '''
        [purpose]: Represents a CD
        [format]:
        Artist's Name: XXX
        Duration: XXX
        Songs: XXX
        '''
        songstr = ""
        for song in self.songs:
            songstr += song + ", "
        songstr = songstr[:-2]
        
        return "Artist Name: {0}\nDuration: {1}\nSongs: {2}".format\
               (self.artist, self.duration, songstr)
    
    def __eq__(self, other):
        ''' [purpose]: checks if two CD objects are the same. '''        
        return isinstance(other, CD) \
               and self.artist == other.artist \
               and self.duration == other.duration \
               and self.songs == other.songs


## Question 2
# Write the Python function output_CD_info that consumes a dictionary
# of CD objects (like the one produced in Q1) and a string. 
# - If the string is not a key in the dictionary, the function should 
#   do nothing.
# - If the string is a key in the dictionary, the function should 
#   create a text file named "Artist - Title".txt, where Artist and 
#   Title relate to the cd found at cd_dict[name].
# - The text file should contain (each on its own line):
#    - the title of the CD in uppercase,
#    - then the artist,
#    - then the duration of the CD (formatted like in question 1),
#    - then a blank line, and
#    - then the index of the song with name of each track in the CD.

d = {"Disney Mix": CD("Various", 912, ["You'll Be in My Heart", "Kiss the Gril",
                                       "Circle of Life", "I'll Make a Man Out of You",
                                       "Whole New World", "Go the Distance"])}
# Example:
# output_CD_info(d, "Disney Mix")


d2 = {"The Final Countdown": CD("Europe", 227, ["The Final Countdown"])}
d3 = {"Disney Mix": CD("Various", 912, ["You'll Be in My Heart", "Kiss the Girl",
                                        "Circle of Life", "I'll Make a Man Out of You",
                                        "Whole New World", "Go the Distance"]),
      "Code Monkey": CD("Jonathan Coulton", 203, ["Code Monkey"]),
      "Close to the Edge": CD("Yes", 2266, ["Close to the Edge", "And You and I", "Siberian Khatru"]),
      "Wish You Were Here (Side 1)": CD("Pink Floyd", 1268, ["Shine On You Crazy Diamond (1-5)",
                                                             "Welcome to the Machine"]),
      "Abbey Road": CD("The Beatles", 255, ["Mean Mr. Mustard",
                                            "Polythene Pam",
                                            "She Came in Through the Bathroom Window"])}

# output_CD_info(cd_dict,name) write the data from the CD object
#   associated with that name to a new file named "artist - title.txt" 
#   if name is a key in cd_dict.
# Effects: write a file if name is in cd_dict
# output_CD_info: (dictof Str CD) Str -> None
# Examples:
# output_CD_info(d2, "The Final Countdown") will create a file with
#     THE FINAL COUNTDOWN on its first line, Europe on its second line, a blank third
#     line, and 1. The Final Countdown on its fourth (and final) line
# output_CD_info(d3, "Disney Mix") will create a file with DISNEY MIX on
#     its first line, Various on its second line, a blank third line, and a list of tracks
#     on the following line in the form 3. Circle of Life 

## writeline

def output_CD_info(cd_dict, name):
    pass

### Tests ### 
# 1st set of tests: key not in dictionary, no file is created
check.expect("Test 1", output_CD_info({}, "Aquarium"), None)
check.expect("Test 2", output_CD_info(d3, "Aquarium"), None)

# 2nd set of tests: files created, compare content
check.set_file_exact("Europe - The Final Countdown.txt", 
        "output_CD_info_3.txt")
check.expect("Test 3", output_CD_info(d2, "The Final Countdown"), None)

check.set_file_exact("The Beatles - Abbey Road.txt", 
        "output_CD_info_4.txt")
check.expect("Test 4", output_CD_info(d3, "Abbey Road"), None)
