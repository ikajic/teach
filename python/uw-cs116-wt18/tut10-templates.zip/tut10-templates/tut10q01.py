## Tutorial 10

import check

class CD:

    def __init__(self, artist, dur, los):
        '''
        [purpose]: Initializes a CD
        [fields]:
           * artist (artist's name) - Str
           * duration (duration of CD in seconds) - Int
           * songs (list of artist's songs) - (listof Str)
        '''
        self.artist = artist
        self.duration = dur
        self.songs = los
    
    def __repr__(self):
        '''
        [purpose]: Represents a CD
        [format]:
        Artist's Name: XXX
        Duration: XXX
        Songs: XXX
        '''
        songstr = ""
        for song in self.songs:
            songstr += song + ", "
        songstr = songstr[:-2]
        
        return "Artist Name: {0}\nDuration: {1}\nSongs: {2}".format\
               (self.artist, self.duration, songstr)
    
    def __eq__(self, other):
        ''' [purpose]: checks if two CD objects are the same. '''        
        return isinstance(other, CD) \
               and self.artist == other.artist \
               and self.duration == other.duration \
               and self.songs == other.songs



## Question 1
# Write the Python function make_cd_dict that reads the data from
# a text file and converts the data into a dictionary of CD objects,
# with keys equal to the name of the CD.
#   { album title: CD(artist, duration, [listof songs]) }

# Dictionaries for testing
d2 = {"The Final Countdown": CD("Europe", 227, ["The Final Countdown"])}
d3 = {"Disney Mix": CD("Various", 912, ["You'll Be in My Heart", "Kiss the Girl",
                                        "Circle of Life", "I'll Make a Man Out of You",
                                        "Whole New World", "Go the Distance"]),
      "Code Monkey": CD("Jonathan Coulton", 203, ["Code Monkey"]),
      "Close to the Edge": CD("Yes", 2266, ["Close to the Edge", "And You and I", "Siberian Khatru"]),
      "Wish You Were Here (Side 1)": CD("Pink Floyd", 1268, ["Shine On You Crazy Diamond (1-5)",
                                                             "Welcome to the Machine"]),
      "Abbey Road": CD("The Beatles", 255, ["Mean Mr. Mustard",
                                            "Polythene Pam",
                                            "She Came in Through the Bathroom Window"])}


# make_cd_dict(fname) reads data from a file called fname and outputs
#   a dictionary of CD objects
# Effects: reads data from a file and creates a dict of CD objects
#          from the data
# make_cd_dict: Str -> (dictof Str CD)
# Examples:
# If the file is blank, the function will produce {}
# make_cd_dict('make_cd_dict_2.txt') => d2


## readline()
def make_cd_dict(fname):
    pass

### Tests ###

# Blank File
check.expect("Test 1", make_cd_dict("make_cd_dict_1.txt"), {})

# File with one CD
check.expect("Test 2", make_cd_dict("make_cd_dict_2.txt"), d2)

# File with multiple CDs
check.expect("Test 3", make_cd_dict("make_cd_dict_3.txt"), d3)
