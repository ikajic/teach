## Tutorial 6 Midterm Review
# Source: Coding Bat, http://codingbat.com/prob/p174314

import check
import math

# Question 2 (Module 3 - Strings)
# Write a function called ends_with_other that consumes two strings,
# s and t, and returns True if s ends with t or if t ends with s,
# False otherwise. This function should be case insensitive.
# Examples:
# ends_with_other("abc", "Hi abc") => True
# ends_with_other("HELLO", "hello") => True
# ends_with_other("abc", "def") => False

## Recursive Solution
# ends_with_acc(s,t,pos) returns True if s ends with t, False
#   otherwise, and pos keeps track of the postion to check.
# ends_with_acc: Str Str Nat -> Bool
def ends_with_acc(s, t, pos):
    if pos ???? len(t):
        return ????
    elif ????:
        return ends_with_acc(s,t,pos+1)
    return ????

# ends_with_other(s,t) returns True if either s ends with t or
#   t ends with s, False otherwise.
# ends_with_other: Str Str -> Bool
# Examples:
# ends_with_other("", "") => True
# ends_with_other("HELLO", "hello") => True
# ends_with_other("abc", "def") => False

def ends_with_other(s, t):
    if ????:  # what is one of the strings is empty? 
        return ????
    elif (len(s) > len(t)):  # what if one of the strings is longer?
        return ends_with_acc(????)
    return ends_with_acc(????)

# Tests:
check.expect("Q2T1", ends_with_other("abc", "Hi abc"), True)
check.expect("Q2T2", ends_with_other("HELLO", "hello"), True)
check.expect("Q2T3", ends_with_other("abc", "def"), False)
check.expect("Q2T4", ends_with_other("", ""), ????)